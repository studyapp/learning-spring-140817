package com.yapp.urlshorter.exception;

public class BadRequestException extends RuntimeException {
	private static final long serialVersionUID = 4451878030103078351L;

}
